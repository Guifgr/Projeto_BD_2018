<?php
	$conn = mysqli_connect('localhost', 'root', '');
	$selectDB = mysqli_select_db($conn, 'busbuy');
?>