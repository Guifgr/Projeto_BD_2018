<html>
	<head>
	<meta charset="utf-8">
	
	
	</head>
	<body>
	
		<input type="text" name="nome" placeholder="Digite seu nome"/>
		<input type="text" name="cpf" placeholder="Digite seu cpf"/>
		<input typer="tel" name="tel" placeholder="digite seu telefone"/>
		<input typer="email" name="email" placeholder="digite seu email"/>
		<textarea cols="4"/>
	</body>
</html>