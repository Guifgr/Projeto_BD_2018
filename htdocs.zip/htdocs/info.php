<?php 
include("db_connect.php");
if(isset($_POST['enviar'])){
    $Tipo = $_POST['tipo'];
    $email = mysqli_escape_string($connect,$_POST['email']);
    $cpf = mysqli_escape_string($connect,$_POST['cpf']);
    $nome = mysqli_escape_string($connect,$_POST['nome']);
    $senha = mysqli_escape_string($connect,$_POST['senha']);
    $senha = md5($senha);
    $sql = "SELECT * FROM funcionario";
    $resultado = mysqli_query($connect,$sql);
    $dados = mysqli_fetch_array($resultado);
    $emails = $dados['emailFuncionario'];
    $cpfs = $dados['cpfFuncionario'];
    if(empty($email) or empty($senha) or empty($cpf) or empty($nome)){
        echo '<script type="text/javascript">
                alert("Preencha todos os campos");
            </script>';
                
        }
    elseif($emails == $email || $cpfs == $cpf){
                echo '<script type="text/javascript">
                alert("Você já possui cadastro");
            </script>';
                
    }else{$sql = "INSERT INTO funcionario (cpfFuncionario, nomeFuncionario, emailFuncionario, senhaFuncionario) VALUES ('$cpf', '$nome', '$email', '$senha')";
            if(mysqli_query($connect, $sql)){
                if($Tipo == "Sac"){
                   $sac = mysqli_query($connect, "INSERT INTO funcionariosac (cpfSac) VALUES ('$cpf')");
                   }else{
                   $venda =mysqli_query($connect, "INSERT INTO funcionariovenda (cpfVenda) VALUES ('$cpf')");
                   }
                header('Location: gerente.php');
            }else{
                header('Location: info.php');
            }
        }
   
}
?>
<html>
    <head>
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <meta charset="utf-8">
        <style>
            body{background-image:linear-gradient(blueviolet, white);background-size: cover}
           #enviar{border-radius: 10px;color: blueviolet;cursor: pointer}
            img{width: 500px;height: 300px;position: fixed;top: 0;right: 300px}
            
        </style>    
    </head>
    <body>
    
        
        <form method="POST">
            <br><br><br><br><br><br><br><br><br><br><br><br><br>
            <select type="text" name="tipo" id="tipo">
                    <option value="">Selecione</option>
                    <option value="Sac">Sac</option>
                    <option value="Venda">Venda</option>
            </select>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Email</span>
                    </div>
                <input type="email" class="form-control" placeholder="Digite" name="email" aria-label="Username" aria-describedby="basic-addon1">
                </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Nome</span>
                    </div>
                <input type="text" class="form-control" placeholder="Digite" name="nome" aria-label="Username" aria-describedby="basic-addon1">
                </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">CPF</span>
                    </div>
                <input type="text" class="form-control" placeholder="Digite" name="cpf" aria-label="Username" aria-describedby="basic-addon1">
                </div>
                 <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Senha</span>
                    </div>
                <input type="password" class="form-control" placeholder="Digite" name="senha" aria-label="Username" aria-describedby="basic-addon1">
                <input type="submit" id="enviar" name="enviar">
                </div>
             <a href="gerente.php"><button  name="cancelar" type="button" class="btn btn-danger">cancela</button></a>
            
            <img src="BBCOMPLETE.png"/>
        </form>
    
    </body>
    
    