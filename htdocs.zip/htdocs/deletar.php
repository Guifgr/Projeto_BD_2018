<?php

include("topBar.php");
include("db_connect.php");




?>
<html>

	<head>
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
	 	<meta charset="utf-8">	
		
		<style>
		img{width: 500px;height: 300px;position: fixed;top: 11%;right: 700px}
		body{background-image:linear-gradient(blueviolet, white);}
		h1{font-size: 30; position: fixed;top: 210px;right: 10px}
		</style>
		
	</head>

	<body>
		<img src="BBCOMPLETE.png"/>
		<h1>Sentiremos a sua falta, clique <a id="lol" href="deletar.php">Aqui</a> para deletar de vez sua conta</h1>
	</body>

</html>