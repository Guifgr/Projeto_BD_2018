<?php
// Conexão com banco de dados
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "trabalho";

$connect = mysqli_connect($servername, $username, $password, $db_name);
mysqli_set_charset($connect, "utf8");
if(mysqli_connect_error()):
	echo "Falha na conexão: ".mysqli_connect_error();
endif;

?>