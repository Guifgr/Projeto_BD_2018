<?php
include("db_connect.php");
$data = '2018-12-05';
$idIda = 'AP';
$idVolta = 'AP';
$nroAssento = '1';
$idAssentoN;







for($i='1'; $i<='42'; $i++){

      $assento[$i] = "Vago";

}
    

for ($i = '0'; $i <= '42' ; $i++) {
$sql = "SELECT * FROM assento WHERE dataX = '$data' AND idVolta_passagem = '$idVolta' AND idIda_passagem ='$idIda' AND nroAssento = '$i'";
$resultado = mysqli_query($connect,$sql);
$dados = mysqli_fetch_array($resultado);

if($dados['idAssento']!= 'NULL'){

$assento[$i] = "Ocupado";

    
}

}



?>
<html>      
<head>
	<meta charset="utf-8">
</head>     
<body>   
<?php echo '<h1>idPassagem '.$dados.' </h1>';?><br>    
<?php echo '<h1>idPassagem '.$dados['idPassagem'].' </h1>';?><br>
<?php echo '<h2> idAssento_passagem '.$dados['idAssento_passagem'].'.</h2>';?> <br>    
<?php echo '<h3>cpfCliente_passagem '.$dados['cpfCliente_passagem'].' .</h3>';?> <br>
<?php echo '<h1>idVenda_passagem '.$dados['idVenda_passagem'].' .</h1>';?><br>
<?php echo '<h2>idVolta_passagem '.$dados['idVolta_passagem'].' .</h2>';?> <br>    
<?php echo '<h3>idIda_passagem '.$dados['idIda_passagem'].' .</h3>';?> <br>
<?php echo '<h1>idRota_passagem '.$dados['idRota_passagem'].' .</h1>';?><br>
<?php echo '<h2>data '.$dados['dataX'].' .</h2>';?> <br>    
 </body> 
   </html>