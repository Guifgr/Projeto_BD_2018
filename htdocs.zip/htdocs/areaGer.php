<?php
include("db_connect.php");

if(isset($_POST['enviar'])):
	$erros = array();
	$cpf = mysqli_escape_string($connect,$_POST['cpf']);
	$senha = mysqli_escape_string($connect,$_POST['senha']);
	if(empty($cpf) or empty($senha)):
		$erros[] = "<troia> O campo cpf/senha precisa ser preenchido </troia>";
	else:
		$sql = "select cpfFuncionario from funcionario where cpfFuncionario = '$cpf'";
		$resultado = mysqli_query($connect,$sql);
		if(mysqli_num_rows($resultado) > 0):
			$senha = md5($senha);
			$sql = "select * from funcionario where cpfFuncionario = '$cpf' and senhaFuncionario = '$senha' ";
			$resultado = mysqli_query($connect,$sql);
			if(mysqli_num_rows($resultado) == 1):
				$dados = mysqli_fetch_array($resultado);
				$_SESSION['logado'] = true;
				$_SESSION['cpf_funcionario'] = $dados['cpfFuncionario'];
				header('Location: gerente.php');
			else:
				$erros[] = "<pedro> Usuário e senha não conferem </pedro>";
			endif;
		else:
			$erros[] = "<cavalo> Usuário inexistente </cavalo>";
		endif;
	endif;
endif;
?>
<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     	
		<meta charset="utf-8">
		<style>
			#centro {
				width:100px;
				height:100px;
				position:absolute;
				top:60%;
				left:45%;
				}
			input[type="text"]{border-radius: 20px;}
			input[name="senha"]{border-radius: 20px}
			input[name="enviar"]{color:blueviolet;border-radius: 10px;cursor: pointer}
			a[name="link"]{position: fixed;right: 38%;top: 76%;font-size: 15px}
			a[name="linkA"]{position: fixed;right: 38%;top: 79%;font-size: 15px}
			 
			
			body{background-image:linear-gradient(blueviolet, white);}

			
			h1{background-color: blueviolet; color: white;font-family: cursive;position: fixed;font-size: 55px;right: 40%;top: 15%}
			h2{color: blueviolet;position: fixed;font-size: 30px;right: 29%;top: 50%}
			img{width: 500px;height: 300px}
			pedro{position: fixed;right: 24%;top: 64%;font-family: cursive;color: red}
			cavalo{position: fixed;right: 30%;top: 64%;font-family: cursive;color: red}
			troia{position: fixed;right: 17%;top: 64%;font-family: cursive;color: red}
			
		</style>
		
	</head>
		<?php 
				if(!empty($erros)):
					foreach($erros as $erro):
						echo $erro;
					endforeach;
				endif;
	?>
	<body>
		<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
		<div id="centro">
			<input type="text" placeholder="  cpf sem traços e ponto" name="cpf"/>
			<br>
			<input type="password" placeholder="		Senha" name="senha"/>
			<input type="submit" placeholder="entrar" name="enviar" />
		</div>
		</form>
		<div id="link">
			<a name="linkA"href="index.php">Voltar ao início</a>
			<img src="BBCOMPLETE.png"/>
		</div>
		
		<h1>Bem vindo!</h1>
		<h2>Faça seu login aqui (Área de Gerentes)</h2>
		
		
	</body>
</html>