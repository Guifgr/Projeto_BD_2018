<?php
//includes
include("db_connect.php");
//sessão
session_start();
//botão enviar
if(isset($_POST['enviar'])):
	$erros = array();
	$email = mysqli_escape_string($connect,$_POST['email']);
	$senha = mysqli_escape_string($connect,$_POST['senha']);
	if(empty($email) or empty($senha)):
		$erros[] = "<troia> O campo email/senha precisa ser preenchido </troia>";
	else:
		$sql = "select emailCliente from cliente where emailCliente = '$email'";
		$resultado = mysqli_query($connect,$sql);
		if(mysqli_num_rows($resultado) > 0):
			$senha = md5($senha);
			$sql = "select * from cliente where emailCliente = '$email' and senhaCliente = '$senha' ";
			$resultado = mysqli_query($connect,$sql);
			if(mysqli_num_rows($resultado) == 1):
				$dados = mysqli_fetch_array($resultado);
				$_SESSION['logado'] = true;
				$_SESSION['cpf_cliente'] = $dados['cpfCliente'];
				header('Location: Home.php');
			else:
				$erros[] = "<pedro> Usuário e senha não conferem </pedro>";
			endif;
		else:
			$erros[] = "<cavalo> Usuário inexistente </cavalo>";
		endif;
	endif;
endif;
?>
<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
		<meta charset="utf-8">
		<style>
			img{position: fixed; width: 500px;height: 300px}
			#centro {
				width:100px;
				height:100px;
				position:absolute;
				top:60%;
				left:45%;
				}
			input[name="email"]{border-radius: 20px;}
			input[name="senha"]{border-radius: 20px}
			input[name="enviar"]{cursor: pointer; border-radius: 10px;color: blueviolet}
			#link[id="link"]{position: fixed;right: 39%;top: 72%;font-size: 15px}
			 
			
			body{background-image:linear-gradient(blueviolet, white);}

			
			h1{background-color: blueviolet; color: white;font-family: cursive;position: fixed;font-size: 55px;right: 40%;top: 15%}
			h2{color: blueviolet;position: fixed;font-size: 30px;right: 29%;top: 50%}
			pedro{position: fixed;right: 24%;top: 61%;font-family: cursive;color: red}
			cavalo{position: fixed;right: 30%;top: 61%;font-family: cursive;color: red}
			troia{position: fixed;right: 17%;top: 61%;font-family: cursive;color: red}
			
		</style>
		
	</head>
	<?php 
				if(!empty($erros)):
					foreach($erros as $erro):
						echo $erro;
					endforeach;
				endif;
	?>
	<body>
		<img src="BBCOMPLETE.png"/>
		<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
		<div id="centro">
			<input type="email" placeholder="	Digite seu email" name="email"/>
			<input type="password" placeholder="		Senha" name="senha"/>
			<input type="submit" placeholder="entrar" name="enviar" href="pesquisa.php"/>
		</div>
		<div id="link">
			<a href="cadastro.php">Cadastre-se aqui</a><br>
			<a href="resetpass.php" id="alterar">Esqueceu a senha?</a>
			<br>
			<a href="areaFunc.php" id="func">Funcionários</a>
		</div>
		</form>
		
		<h1>Bem vindo!</h1>
		<h2>Faça seu login para apriveitar as melhores ofertas</h2>
		
		
	</body>
</html>