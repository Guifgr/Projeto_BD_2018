<?php
include("db_connect.php");

if(isset($_POST['enviar'])){
	$email = mysqli_escape_string($connect,$_POST['email']);
	$cpf = mysqli_escape_string($connect,$_POST['cpf']);
	$nome = mysqli_escape_string($connect,$_POST['nome']);
	$senha = mysqli_escape_string($connect,$_POST['senha']);
	$senha = md5($senha);
	$sql = "SELECT * FROM cliente";
	$resultado = mysqli_query($connect,$sql);
	$dados = mysqli_fetch_array($resultado);
	$emails = $dados['emailCliente'];
	$cpfs = $dados['cpfCliente'];
	if(empty($email) or empty($senha) or empty($cpf) or empty($nome)){
		echo '<script type="text/javascript">
    			alert("Preencha todos os campos");
    		</script>';
				
		}
	elseif($emails == $email || $cpfs == $cpf){
				echo '<script type="text/javascript">
    			alert("Você já possui cadastro");
    		</script>';
				
	}
		   
	else{	$sql = "INSERT INTO cliente (cpfCliente, nomeCliente, emailCliente, senhaCliente) VALUES ('$cpf', '$nome', '$email', '$senha')";
		   

			if(mysqli_query($connect, $sql)){
				header('Location: index.php');
			}else{
				header('Location: cadastro.php');
			}
		}
	}
?>
<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
		<meta charset="utf-8">
		<link href="style4.css" type="text/css" rel="stylesheet">
		<style>
			#centro {
				width:100px;
				height:100px;
				position:absolute;
				top:60%;
				left:45%;
				}
			input[name="email"]{border-radius: 20px;}
			input[name="senha"]{border-radius: 20px}
			input[name="enviar"]{cursor: pointer; border-radius: 10px}
			input[name="cpf"]{border-radius: 20px;}
			input[name="nome"]{border-radius: 20px;}
			input[name="enviar"]{border-radius: 10px;color: blueviolet}
			 
			
			body{background-image:linear-gradient(blueviolet, white);}

			
			h1{color: #FFFFCC;font-family: cursive;position: fixed;font-size: 55px;right: 40%;top: 10%}
			h2{color: #FFFFCC;position: fixed;font-size: 30px;right: 25%;top: 50%}
			img{width: 500px;height: 300px}
			a{font-size: 20; position: fixed;top: 10px;right: 10px}
		</style>

		
	</head>
	<body>
		<form action=<?php echo $_SERVER['PHP_SELF'];?> method="POST">
		<div id="centro">
			<input type="email" placeholder="	Digite seu email" name="email" id="email"/>
			<input type="text" placeholder="		Cpf" name="cpf" id="cpf"/>
			<input type="text" placeholder="		nome" name="nome" id="nome"/>
			<input type="password" placeholder="		Senha" name="senha" id="senha"/>
			
			<input type="submit" name="enviar" />
		</div>
		<div id="link">
			<img src="BBCOMPLETE.png"/>
		</div>
		</form>
		<h1>Bem vindo!</h1>
		<h2>Faça seu cadastro para apriveitar as melhores ofertas</h2>
		<a id="casa" href="index.php">Voltar ao início</a>
		
	</body>
</html>