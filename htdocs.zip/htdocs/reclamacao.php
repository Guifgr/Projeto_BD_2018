<?php 
include("topBar.php");
include("db_connect.php");


if(isset($_POST['enviar'])){
	$nome = mysqli_escape_string($connect,$_POST['nome']);
	$cpf = mysqli_escape_string($connect,$_POST['cpf']);
	$email = mysqli_escape_string($connect,$_POST['email']);
	$reclamacao = mysqli_escape_string($connect,$_POST['reclama']);
	$sql = "select idSac from funcionariosac";
	$resultado = mysqli_query($connect,$sql);
	$idSac = mt_rand(1,mysqli_num_rows($resultado));

	if(empty($nome) or empty($cpf) or empty($email) or empty($reclamacao)){
		echo '<script type="text/javascript">
    			alert("Preencha todos os campos");
    		</script>';		
		}
	else{
		$sql = "INSERT INTO reclamacao (cpfCliente_reclamacao, nome, email,reclamacao, idSac_reclamacao) VALUES ('$cpf', '$nome', '$email', '$reclamacao','$idSac')";
		
		if(mysqli_query($connect, $sql)){
				header('Location: Home.php');
				}
		
		else{
				header('Location: reclamacao.php');
				}
	}
}
?>




<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
		<link href="style3.css" rel="stylesheet">
	   <meta charset="utf-8">
        
	</head>
	<body>
	<form action=<?php echo $_SERVER['PHP_SELF'];?> method="POST">	
	<div id="submits">
		<input type="text" name="nome" placeholder="Digite seu nome"/>
		<br/>
		<input type="text" name="cpf" placeholder="Digite seu cpf"/>
		<br/>
		<input typer="email" name="email" placeholder="digite seu email"/>
		<br/>
    </div>

        <div id="text">
            <textarea cols="50" rows="15" name="reclama" placeholder="Digite aqui sua reclamação"></textarea>
        </div>
		
        <div id="submit">
        <input type="submit" name="enviar" placeholder="enviar"/>   
        </div>
		</form>
		<img src="BBCOMPLETE.png"/>
	</body>    
</html>