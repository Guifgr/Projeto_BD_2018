<?php 
	include("topBar.php");
	include("db_connect.php");
?>
<html>
	<head>
		<meta charset="utf-8">
		<style>
			#centro {
				width:100px;
				height:100px;
				position:fixed;
				margin: 0 auto;
				}
			body{background-image:linear-gradient(blueviolet, white);}
			img{width: 500px;height: 300px;position: fixed;top: 11%;right: 700px}
			#passagens{right: 350px;top: 200px;position: fixed;width: 400px}
			#func{top: 500px;right: 900px;position: fixed}
		</style>
	</head>
	<body>
		
			<div id="centro">
		<form>	
			
		<img src="BBCOMPLETE.png"/>
		<?php
		$sql = "SELECT * FROM passagem";
		$resultado = mysqli_query($connect,$sql);
		while ($dados = mysqli_fetch_array ($resultado)):
		?>
		<div class="list-group" id="passagens">
  <a href="Lido.php" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1">CPF:<?php echo $dados['cpfCliente_passagem']; ?></h5>
    </div>
    <p class="mb-1">DATA:<?php echo $dados['dataX']; ?></p>
    <small class="text-muted">De:<?php echo $dados['idIda_passagem']; ?></small>
	 <br>
	<small class="text-muted">Para:<?php echo $dados['idVolta_passagem']; ?></small>
      <br>
    <small class="text-muted">Nº<?php echo $dados['idPassagem']; ?></small>
      <br>
    <small class="text-muted">Assento Nº<?php echo $dados['idAssento_passagem']; ?></small>
	  
  </a>
</div>
<?php endwhile; ?>
				</form>	
			</div>
			
	</body>
</html>