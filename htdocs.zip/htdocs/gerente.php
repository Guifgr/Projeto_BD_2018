<html>
    <head>
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <meta charset="utf-8">
        <style>
            body{background-image:linear-gradient(blueviolet, white);background-size: cover}
            #insert{position: fixed;top: 400px}
            #create{position: fixed;top: 300px}
            #view{position: fixed;top: 500px}
            h1{position: fixed;right: 400px;top: 15 0px}
            #logoff{position: fixed;top: 0;right: 100px}
        </style>    
    </head>
    <body>
        <h1>Bem vindo gerente<span class="badge badge-secondary">BusBuy</span></h1>
        
        
            <a href="info.php"><button id="create" type="button" class="btn btn-primary btn-lg btn-block">Criar Funcionário</button></a>
       
           <a href="insert.php"><button id="insert" type="button" class="btn btn-secondary btn-lg btn-block">Inserir informações</button></a>
            
             
            <a href="passagens.php"><button id="view" type="button" class="btn btn-secondary btn-lg btn-block">Ver Todas as compras</button></a>
        
      <a class="btn btn-primary" href="logout.php" role="button"id="logoff">Sair</a>
   
    
    </body>
</html>