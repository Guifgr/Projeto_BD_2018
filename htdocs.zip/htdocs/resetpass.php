<?php
	include("db_connect.php");
session_start();
if(isset($_POST['enviar'])):
	$erros = array();
	$email = mysqli_escape_string($connect,$_POST['email']);
	$cpf = mysqli_escape_string($connect,$_POST['cpf']);
	if(empty($email) or empty($cpf)):
		$erros[] = "<troia> O campo email/CPF precisa ser preenchido </troia>";
	else:
		$sql = "select emailCliente from cliente where emailCliente = '$email'";
		$resultado = mysqli_query($connect,$sql);
		if(mysqli_num_rows($resultado) > 0):
			$sql = "select * from cliente where emailCliente = '$email' and cpfCliente = '$cpf' ";
			$resultado = mysqli_query($connect,$sql);
			if(mysqli_num_rows($resultado) == 1):
				$dados = mysqli_fetch_array($resultado);
				$_SESSION['cpf_cliente'] = $dados['cpfCliente'];
				header('Location: onlypass.php');
			else:
				$erros[] = "<pedro> Usuário e CPF não conferem </pedro>";
			endif;
		else:
			$erros[] = "<cavalo> Usuário inexistente </cavalo>";
		endif;
	endif;
endif;

?>
<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    	
		<style>
			
			#centro {
				width:100px;
				height:100px;
				position:absolute;
				top:60%;
				left:45%;
				}
			body{background-image:linear-gradient(blueviolet, white);}
			img{width: 500px;height: 300px}
			input[id="cpf"]{border-radius: 20px}
			input[id="email"]{border-radius: 20px}
			input[name="enviar"]{position: fixed; color:blueviolet;border-radius: 10px;right: 39%;bottom: 27%;cursor: pointer}
			h1{background-color: blueviolet; color: white;font-family: cursive;position: fixed;font-size: 55px;right: 30%;top: 15%}
			h2{color: blueviolet;position: fixed;font-size: 30px;right: 29%;top: 50%}
			pedro{position: fixed;right: 24%;top: 61%;font-family: cursive;color: red}
			cavalo{position: fixed;right: 30%;top: 61%;font-family: cursive;color: red}
			troia{position: fixed;right: 17%;top: 61%;font-family: cursive;color: red}
			
		</style>
	
	</head>
	
	<body>
		<?php 
				if(!empty($erros)):
					foreach($erros as $erro):
						echo $erro;
					endforeach;
				endif;
		?>
		<img src="BBCOMPLETE.png"/>
		<h1>Vamos resolver isto</h1>
		<h2>Precisamos de algumas informações</h2>
		
		<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
		<div id="centro">
		<input name="cpf" type="text" id="cpf" placeholder="	   Digite seu cpf"/>
		<input type="email" name="email" id="email" placeholder="		Email"/>
		<input type="submit" placeholder="entrar" name="enviar" href="onlypass.php"/>
		</div>
		</form>
		
	</body>


</html>