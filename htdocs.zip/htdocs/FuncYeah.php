<?php 
	include("topBar.php");
	include("db_connect.php");
?>
<html>
	<head>
		<meta charset="utf-8">
		<style>
			#centro {
				width:100px;
				height:100px;
				position:fixed;
				margin: 0 auto;
				}
			body{background-image:linear-gradient(blueviolet, white);}
			img{width: 500px;height: 300px;position: fixed;top: 11%;right: 700px}
			#passagens{right: 100px;top: 200px;position: fixed}
			#func{top: 500px;right: 900px;position: fixed}
		</style>
	</head>
	<body>
		
			<div id="centro">
		<form>	
			
		<img src="BBCOMPLETE.png"/>
		<?php
		$sql = "SELECT * FROM reclamacao";
		$resultado = mysqli_query($connect,$sql);
		while ($dados = mysqli_fetch_array ($resultado)):
		?>
		<div class="list-group" id="passagens">
  <a href="Lido.php" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1"><?php echo $dados['cpfCliente_reclamacao']; ?></h5>
    </div>
    <p class="mb-1"><?php echo $dados['reclamacao']; ?></p>
    <small class="text-muted"><?php echo $dados['email']; ?></small>
	 <br>
	<small class="text-muted"><?php echo $dados['nome']; ?></small>
	  
  </a>
</div>
<?php endwhile; ?>
		<div  id="func" class="card border-success mb-3" style="max-width: 18rem;">
  <div class="card-header bg-transparent border-success">Número de reclamações <?php ?></div>
  <div class="card-body text-success">
    <h5 class="card-title">NOME DO FUNCIONARIO</h5>
    <p class="card-text">Bom trabalho aqui na BusBuy</p>
  </div>
  <div class="card-footer bg-transparent border-success">CPF FUNC</div>
</div>
				</form>	
			</div>
			
	</body>
</html>