<?php  
include("topBar.php");
include("db_connect.php");
session_start();

if(isset($_GET['id'])){
		$id = $_GET['id'];
		$destino = $_GET['Dest'];
		$partida = $_GET['Part'];
		$data = $_GET['data'];
	    $selectasento = mysqli_query($connect,"SELECT nroAssento FROM assento A,compra C WHERE C.idVolta='$destino' AND C.idIda='$partida' AND C.dataX='$data'");
			if(isset($_POST['enviar'])):
			$cpfCliente = $_SESSION['cpf_cliente'];
			$nroAssento = $_POST['assento'];
			$selectRota = mysqli_query($connect, "SELECT idRota FROM rota WHERE idVolta='$destino' AND idIda='$partida'");
			$assocRota = mysqli_fetch_array($selectRota);
			$idRota = $assocRota['idRota'];
			$sql = "SELECT idVenda FROM funcionariovenda";
			$resultado = mysqli_query($connect,$sql);
			$idVenda = mt_rand(1,mysqli_num_rows($resultado));
			$assento = mysqli_query($connect,"INSERT INTO assento (nroAssento,idVago,idIda,idVolta,dataX) VALUES ('$nroAssento',1,'$partida','$destino','$data')");
			$selectAssento = mysqli_query($connect,"SELECT idAssento FROM assento WHERE nroAssento = '$nroAssento' ORDER BY nroAssento DESC ");
			$assocAssento = mysqli_fetch_array($selectAssento);
			$idAssento = $assocAssento['idAssento'];
			echo $idAssento;
			
    
                if($passagem = mysqli_query($connect,"INSERT INTO passagem (idAssento_passagem,cpfCliente_passagem,idVenda_passagem,idVolta_passagem,idIda_passagem,idRota_passagem,dataX) VALUES ('$idAssento','$cpfCliente','$idVenda','$destino','$partida','$idRota','$data')")){
				$sql = "SELECT idPassagem FROM passagem WHERE idAssento_passagem = '$idAssento' AND cpfCliente_passagem='$cpfCliente' AND idVenda_passagem='$idVenda' AND idVolta_passagem='$destino' AND idIda_passagem='$partida' AND idRota_passagem ='$idRota' AND dataX='$data'ORDER BY idPassagem DESC";
				$resultado = mysqli_query($connect,$sql);
				$dados = mysqli_fetch_array($resultado);
				$_SESSION['idPassagem']=$dados['idPassagem'];
				header("Location: PGTO.php");	
			}
		endif;
}
	
?>
<html>
<head>
     <title>Compra!</title>
        <link href="styletwo.css" rel="stylesheet">
        <meta charset="utf-8">
	<style>
        #assento{position: fixed;right: 340px;bottom: 310px}
		h2{position:fixed;font-size: 20px;right: 350px;top:200px;background-color: blueviolet;color: white;font-family: fantasy}
		h3{position: fixed; right: 500px;bottom: 300px}
        body{background-image:linear-gradient(blueviolet, white);}
        #bb{width: 500px;height: 300px;position: fixed;top: 11%;right: 700px}
        #bus{position: fixed;bottom: 10px;right: 50px}
        #enviar{position: fixed; border-radius: 10px;color: blueviolet;right: 270px;bottom: 306px}
		</style>
</head>
  <body>
	  
       <form method="POST">
           <select type="text" name="assento" id="assento">
               <option value="">Selecione assento</option>
               <option name="1" value="01">1</option>
               <option name="2" value="02">2</option>
               <option name="3" value="03">3</option>
               <option name="4" value="04">4</option>
               <option name="5" value="05">5</option>
               <option name="6" value="06">6</option>
               <option name="7" value="07">7</option>
               <option name="8" value="08">8</option>
               <option name="9" value="09">9</option>
               <option name="10" value="10">10</option>
               <option name="11" value="11">11</option>
               <option name="12" value="12">12</option>
               <option name="13" value="13">13</option>
               <option name="14" value="14">14</option>
               <option name="15" value="15">15</option>
               <option name="16" value="16">16</option>
               <option name="17" value="17">17</option>
               <option name="18" value="18">18</option>
               <option name="19" value="19">19</option>
               <option name="20" value="20">20</option>
               <option name="21" value="21">21</option>
               <option name="22" value="22">22</option>
               <option name="23" value="23">23</option>
               <option name="24" value="24">24</option>
               <option name="25" value="25">25</option>
               <option name="26" value="26">26</option>
               <option name="27" value="27">27</option>
               <option name="28" value="28">28</option>
               <option name="29" value="29">29</option>
               <option name="30" value="30">30</option>
               <option name="31" value="31">31</option>
               <option name="32" value="32">32</option>
               <option name="33" value="33">33</option>
               <option name="34" value="34">34</option>
               <option name="35" value="35">35</option>
               <option name="36" value="36">36</option>
               <option name="37" value="37">37</option>
               <option name="38" value="38">38</option>
               <option name="39" value="39">39</option>
               <option name="40" value="40">40</option>
               <option name="41" value="41">41</option>
               <option name="42" value="42">42</option>
          </select>
          <input type="submit" name="enviar" id="enviar"/>

          </form>	
	  
	 
	  <?php echo '<h2>Você escolheu ir para '.$destino.' saindo de '.$partida.' em '.$data.'.</h2>';?>
	  <h3> Selecione seu assento: </h3>
	 	<img src="BBCOMPLETE.png" id="bb"/>
        <img src="onibus.png" id="bus"/>
  </body>
</html>