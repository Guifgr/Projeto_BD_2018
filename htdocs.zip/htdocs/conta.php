<?php

include("topBar.php");
include("db_connect.php");
session_start();

?>
<html>

	<head>
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
	 	<meta charset="utf-8">	
		
		<style>
		img{width: 500px;height: 300px;position: fixed;top: 11%;right: 700px}
		body{background-image:linear-gradient(blueviolet, white);}
		#passagens{right: 100px;top: 200px;position: fixed}
		a[id="lol"]{position: fixed;top: 10px;right: 10px}
		</style>
		
	</head>

	<body>
		
		
		<?php
		$cpf = $_SESSION['cpf_cliente'];
		$sql = "SELECT * FROM passagem where cpfCliente_passagem = '$cpf'";
		$resultado = mysqli_query($connect,$sql);
		while ($dados = mysqli_fetch_array($resultado)):
		?>
		<div class="list-group" id="passagens">
  <a href="Lido.php" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1"><?php echo $dados['idPassagem']; ?></h5>
    </div>
    <p class="mb-1"><?php echo $dados['idAssento_passagem']; ?></p>
    <small class="text-muted"><?php echo $dados['idIda_passagem']; ?></small>
	 <br>
	<small class="text-muted"><?php echo $dados['idVolta_passagem']; ?></small>
	<small class="text-muted"><?php echo $dados['dataX']; ?></small>
	  
  </a>
</div>
<?php endwhile; ?>
		
		
		<img src="BBCOMPLETE.png"/>
		<a id="lol" href="deletar.php">Deletar conta</a>
	</body>

</html>