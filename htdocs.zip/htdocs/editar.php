<?php
include 'db_connect.php';
session_start();
if(isset($_POST['alterar'])):
	$cpf = $_SESSION['cpf_cliente'];
	$senha = mysqli_escape_string($connect,$_POST['senha']);
	$senha = md5($senha);
	$sql = "UPDATE cliente SET senhaCliente = '$senha' WHERE cpfCliente = '$cpf'";

		if(mysqli_query($connect, $sql)):
			header('Location: Indexx.php');
		else:
			header('Location: cadastro.php');
			endif;
endif;
?>