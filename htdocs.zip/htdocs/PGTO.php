<?php
include("db_connect.php");
session_start();
$idPassagem = $_SESSION['idPassagem'];
$sql = "SELECT * FROM passagem WHERE idPassagem='$idPassagem'";
$resultado=(mysqli_query($connect, $sql));
$dados = mysqli_fetch_array($resultado);

$idIda = $dados['idIda_passagem'];
$ida = "SELECT * FROM ida WHERE idIda = '$idIda'";
$resultad=(mysqli_query($connect,$ida));
$dadoss = mysqli_fetch_array($resultad);

$idVolta = $dados['idVolta_passagem'];
$volta = "SELECT * FROM volta WHERE idVolta = '$idVolta'";
$resultad=(mysqli_query($connect,$volta));
$dado = mysqli_fetch_array($resultad);

$idAssento = $dados['idAssento_passagem'];
$assento = "SELECT * FROM assento WHERE idAssento = '$idAssento'";
$resulta=(mysqli_query($connect,$assento));
$dad = mysqli_fetch_array($resulta);

$idVenda=  $dados['idVenda_passagem'];
$venda = "SELECT * FROM funcionariovenda WHERE idVenda = '$idVenda'";
$result=(mysqli_query($connect,$venda));
$da = mysqli_fetch_array($result);

$cpfVenda = $da['cpfVenda'];
$cpf = "SELECT * FROM funcionario WHERE cpfFuncionario = '$cpfVenda'";
$resul = (mysqli_query($connect,$cpf));
$d = mysqli_fetch_array($resul);
?>
<html>
	<head>
			<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		
		<style>
			#centro{margin-left: 40%}
		</style>
	</head>
	<body>
		<div id="centro" class="card" style="width: 18rem;">
  <img class="card-img-top" src="BBCOMPLETE.png" alt="Imagem de capa do card">
  <div class="card-body">
    <h5 class="card-title">Nós da BusBuy agradecemos apreferência</h5>
    <p class="card-text">Viagem reservada a espera do pagamento do boleto 1-3 dias em conta </p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Passagem nº:<?php echo $idPassagem; ?> </li>
    <li class="list-group-item">De:<?php echo $dadoss['estado_ida']; ?> Para:<?php echo $dado['estados_volta']; ?></li>
    <li class="list-group-item">Assento nº:<?php echo $dad['nroAssento']; ?></li>
	<li class="list-group-item">Cpf:<?php echo $dados['cpfCliente_passagem']; ?></li>
	 <li class="list-group-item">Vendedor <?php echo $d['nomeFuncionario']; ?></li>
  </ul>
  <div class="card-body">
    <a href="logout.php" class="card-link">Logout</a>
    <a href="Home.php" class="card-link">Continuar comprando</a>
  </div>
</div>
	</body>

</html>