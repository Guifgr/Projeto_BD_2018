<?php
	include("topbar.php");
	include("db_connect.php");

?>
<html>
	<head>
	
		<style>
			#centro {
				width:100px;
				height:100px;
				position:absolute;
				top:60%;
				left:45%;
				}
			body{background-image:linear-gradient(blueviolet, white);}
			img{width: 500px;height: 300px}
			input[id="password"]{border-radius: 20px}
			input[name="enviar"]{position: fixed; color:blueviolet;border-radius: 10px;right: 42%;bottom: 27%;cursor: pointer}
			h1{background-color: blueviolet; color: white;font-family: cursive;position: fixed;font-size: 55px;right: 30%;top: 15%}
			h2{color: blueviolet;position: fixed;font-size: 30px;right: 35%;top: 50%}
		</style>
	
	</head>
	
	<body>
	<form action="editar.php" method="POST">
		<img src="BBCOMPLETE.png"/>
		<h1>Vamos resolver isto</h1>
		<h2>Digite sua nova senha</h2>
		<div id="centro">
		<input name="senha" type="password" id="cpf" placeholder="Digite sua nova senha"/>
		<input type="submit" placeholder="entrar" name="alterar"/>
		</div>
		</form>
		
	</body>


</html>